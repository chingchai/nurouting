Timeslider / Dateslider based on: http://code.google.com/p/dateslider/

The dateslider component is build upon:
http://prototypejs.org/
http://script.aculo.us/
https://code.google.com/p/datejs/

The original dateslider component was upgraded (latest Scriptaculous/Prototype version) and integrated in Heron as a User Extension (ux), including making an API for configuration and some bug-fixing.

See the Heron timeslider example index.html for the crucial order of loading the frameworks to prevent unwanted behaviour.
