.. module:: gxp.data
    :synopsis: A collection of map data related classes.

:mod:`gxp.data`
===============

The :mod:`gxp.data` module contains classes that extend map related
functionality to ``Ext.data`` classes.

.. toctree::
   :maxdepth: 1
   :glob:
   
   data/*
