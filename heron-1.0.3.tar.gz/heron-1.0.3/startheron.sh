#!/bin/sh

# Start the Python Webserver
python startheron.py $*

