Heron.examples.searchPanelConfig = {
    xtype: 'hr_multisearchcenterpanel',
    height: 600,
    hropts: [
        {
            searchPanel: {
                xtype: 'hr_searchbydrawpanel',
                name: __('ค้นหาโดยใช้เมาส์วาด'),
                header: false
            },
            resultPanel: {
                xtype: 'hr_featuregridpanel',
                id: 'hr-featuregridpanel',
                header: false,
                autoConfig: true,
                autoConfigMaxSniff: 100,
                exportFormats: ['XLS', 'GMLv2', 'GeoJSON', 'WellKnownText', 'Shapefile'],
                gridCellRenderers: Heron.options.gridCellRenderers,
                hropts: {
                    zoomOnRowDoubleClick: true,
                    zoomOnFeatureSelect: false,
                    zoomLevelPointSelect: 12,
                    zoomToDataExtent: false
                }
            }
        },{
            searchPanel: {
                xtype: 'hr_searchbyfeaturepanel',
                name: __('ค้นหาโดยใช้ขอบเขตชั้นข้อมูล'),
                description: 'Select feature-geometries from one layer and use these to perform a spatial search in another layer.',
                header: false,
                border: false,
                bodyStyle: 'padding: 6px',
                style: {
                    fontFamily: 'Verdana, Arial, Helvetica, sans-serif',
                    fontSize: '12px'
                }
            },
            resultPanel: {
                xtype: 'hr_featuregridpanel',
                id: 'hr-featuregridpanel',
                header: false,
                border: false,
                autoConfig: true,
                exportFormats: ['XLS', 'GMLv2', 'GeoJSON', 'WellKnownText', 'Shapefile'],
                gridCellRenderers: Heron.options.gridCellRenderers,
                hropts: {
                    zoomOnRowDoubleClick: true,
                    zoomOnFeatureSelect: false,
                    zoomLevelPointSelect: 12,
                    zoomToDataExtent: false
                }
            }
        },{
            searchPanel: {
                xtype: 'hr_gxpquerypanel',
                name: __('ค้นหาโดยกำหนดเงื่อนไข'),
                description: 'This search uses both search within Map extent and/or your own attribute criteria',
                header: false,
                border: false,
                caseInsensitiveMatch: true,
                autoWildCardAttach: true
            },
            resultPanel: {
                xtype: 'hr_featuregridpanel',
                id: 'hr-featuregridpanel',
                header: false,
                border: false,
                autoConfig: true,
                exportFormats: ['XLS', 'GMLv2', 'GeoJSON', 'WellKnownText', 'Shapefile'],
                gridCellRenderers: Heron.options.gridCellRenderers,
                hropts: {
                    zoomOnRowDoubleClick: true,
                    zoomOnFeatureSelect: false,
                    zoomLevelPointSelect: 12,
                    zoomToDataExtent: true
                }
            }
        }
    ]
};

Heron.options.map.toolbar = [    
    {type: "featureinfo", options: {
        popupWindow: {
            width: 400,
            height: 340,
            featureInfoPanel: {
                showTopToolbar: true,

                // Should column-names be capitalized? Default true.
                columnCapitalize: true,

                // Export to download file. Option values are 'CSV', 'XLS', or a Formatter object (see FeatureGridPanel) , default is no export (results in no export menu).
                exportFormats: ['CSV', 'XLS', 'GMLv2', 'Shapefile',
                    {
                        name: 'Esri Shapefile (WGS84)',
                        formatter: 'OpenLayersFormatter',
                        format: 'OpenLayers.Format.GeoJSON',
                        targetFormat: 'ESRI Shapefile',
                        targetSrs: 'EPSG:4326',
                        fileExt: '.zip',
                        mimeType: 'application/zip'
                    },{
                        // Try this with PDOK Streekpaden and Fietsroutes :-)
                         name: 'GPS File (GPX)',
                         formatter: 'OpenLayersFormatter',
                         format: 'OpenLayers.Format.GeoJSON',
                         targetSrs: 'EPSG:4326',
                         targetFormat: 'GPX',
                         fileExt: '.gpx',
                         mimeType: 'text/plain'
                     },
                    'GeoJSON', 'WellKnownText'],
                // Export to download file. Option values are 'CSV', 'XLS', default is no export (results in no export menu).
                // exportFormats: ['CSV', 'XLS'],
                maxFeatures: 10,

                // In case that the same layer would be requested more than once: discard the styles
                discardStylesForDups: true
            }
        }
    }},
    {type: "-"} ,
    {type: "pan"},
//    {type: "pan", options: {iconCls: "icon-hand"}},
    {type: "zoomin"},
    {type: "zoomout"},
    {type: "zoomvisible"},
    //{type: "coordinatesearch", options: {onSearchCompleteZoom: 8}},
    {type: "-"} ,
    {type: "zoomprevious"},
    {type: "zoomnext"},
    {type: "-"},
// Use "geodesic: true" for non-linear/Mercator projections like Google, Bing etc 
    {type: "measurelength", options: {geodesic: false}},
    {type: "measurearea", options: {geodesic: false}}
   // {type: "-"},
    //{type: "addbookmark"},
    //{type: "help", options: {tooltip: 'Help and info for this example', contentUrl: 'help.html'}},
/*	{type: "-"},
    {
        type: "searchcenter",
        // Options for SearchPanel window
        options: {
            show: false,

            searchWindow: {
                title: __('เครื่องมือค้นหา'),
                x: 100,
                y: undefined,
                width: 660,
                height: 440,
                items: [
                    Heron.examples.searchPanelConfig
                ]
            }
        }
    } */
	//{type: "-"} ,
    //{type: "printdialog", options: {url: 'http://10.39.102.56:8080/geoserver/pdf'
        // , showTitle: true
        // , mapTitle: 'My Header - Print Dialog'
        // , mapTitleYAML: "mapTitle"		// MapFish - field name in config.yaml - default is: 'mapTitle'
        // , showComment: true
        // , mapComment: 'My Comment - Print Dialog'
        // , mapCommentYAML: "mapComment"	// MapFish - field name in config.yaml - default is: 'mapComment'
        // , showFooter: true
        // , mapFooter: 'My Footer - Print Dialog'
        // , mapFooterYAML: "mapFooter"	// MapFish - field name in config.yaml - default is: 'mapFooter'
        // , showRotation: true
        // , showLegend: true
        // , showLegendChecked: true
        // , mapLimitScales: false
    //}}
];

// The content of the HTML info panel.
Ext.namespace("Heron.options.info");
Heron.options.info.html =
        '<div class="hr-html-panel-body"><p>This is the Heron Mapping Client.' +
                '</p><br/><p>This viewer and in fact the entire website has been made with the Open Source' +
                ' project <a href="http://heron-mc.org" target="_new" >Heron Mapping Client</a>. This on ' +
                '<a href="http://geoext.org">GeoExt</a>-based Viewer is very flexible and extensible ' +
                'See examples like <a href="http://inspire.kademo.nl" target="_new">Heron MC for Kademo INSPIRE</a>.</p><br/></div>'

/** Values for BookmarksPanel (bookmarks to jump to specific layers/zoom/center on map. */
Ext.namespace("Heron.options.bookmarks");
Heron.options.bookmarks =
        [
            {
				id: 'id_TK',
				name: 'จ.ตาก',
				desc: 'จ.ตาก',
				layers: ['ขอบเขตจังหวัด'],
				x: 10997562.69823,
				y: 1873091.388291,
				zoom: 8
			},{
				id: 'id_ST',
				name: 'จ.สุโขทัย',
				desc: 'จ.สุโขทัย',
				layers: ['ขอบเขตจังหวัด', 'ขอบเขตอำเภอ'],
				x: 11099835.634671,
				y: 1951517.849437,
				zoom: 9
			}
        ];