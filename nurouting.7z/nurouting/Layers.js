Ext.namespace("Heron.options");
Ext.namespace("Heron.scratch");
Ext.namespace("Heron.examples");

OpenLayers.Util.onImageLoadErrorColor = "transparent";
OpenLayers.ProxyHost = "/cgi-bin/proxy.cgi?url=";
OpenLayers.DOTS_PER_INCH = 25.4 / 0.28;

Ext.BLANK_IMAGE_URL = 'http://cdnjs.cloudflare.com/ajax/libs/extjs/3.4.1-1/resources/images/default/s.gif';

Ext.namespace("Heron.options.map");
//Ext.namespace("Heron.PDOK");

Heron.options.map.settings = {
    projection: 'EPSG:900913',
	displayProjection: new OpenLayers.Projection("EPSG:4326"),
	units: 'm',
	maxExtent: '-20037508.34, -20037508.34, 20037508.34, 20037508.34',
	center: '11141190.727,1898223.243',
	maxResolution: '15543.0339',//'0.17578125',
	xy_precision: 5,
	zoom: 10,
	theme: null,
};


Ext.namespace("Heron.options.wfs");
Heron.options.wfs.downloadFormats = [
    {
        name: 'CSV',
        outputFormat: 'csv',
        fileExt: '.csv'
    }
];

Heron.scratch.urls = {
	OWS: 'http://localhost/geoserver/ows?'
};

Heron.scratch.layermap = {
    //BaseLayers
	gstr: new OpenLayers.Layer.Google(
			"Google Streets", // the default
			{type: google.maps.MapTypeId.ROADMAP, visibility: true},
			{singleTile: false, buffer: 0, isBaseLayer: true}
	),
	gsat: new OpenLayers.Layer.Google(
			"Google Satellite",
			{type: google.maps.MapTypeId.SATELLITE, visibility: false},
			{singleTile: false, buffer: 0, isBaseLayer: true}
	),	
	ghyb: new OpenLayers.Layer.Google(
			"Google Hybrid",
			{type: google.maps.MapTypeId.HYBRID, visibility: false},
			{singleTile: false, buffer: 0, isBaseLayer: true}
	),
	gter: new OpenLayers.Layer.Google(
			"Google Terrain",
			{type: google.maps.MapTypeId.TERRAIN, visibility: false},
			{singleTile: false, buffer: 0, isBaseLayer: true}
	),
	
	//Overlays GeoServer
	ServiceArea: new OpenLayers.Layer.WMS(
            "ServiceArea",
            Heron.scratch.urls.OWS,
            {layers: "nurouting:alpha_polygon", transparent: true, format: 'image/png'},
            {singleTile: false, opacity: 0.5, isBaseLayer: false, visibility: true, noLegend: false, 
			featureInfoFormat: 'application/vnd.ogc.gml', transitionEffect: 'null', metadata: {
                wfs: {
                    protocol: 'fromWMSLayer',
                    downloadFormats: Heron.options.wfs.downloadFormats
                }
            }}
    ),
	Transportation: new OpenLayers.Layer.WMS(
            "Transportation",
            Heron.scratch.urls.OWS,
            {layers: "nurouting:transportation", transparent: true, format: 'image/png'},
            {singleTile: false, opacity: 0.4, isBaseLayer: false, visibility: true, noLegend: false, 
			featureInfoFormat: 'application/vnd.ogc.gml', transitionEffect: 'null', metadata: {
                wfs: {
                    protocol: 'fromWMSLayer',
                    downloadFormats: Heron.options.wfs.downloadFormats
                }
            }}
    ),
	Route: new OpenLayers.Layer.WMS(
            "Route",
            Heron.scratch.urls.OWS,
            {layers: "nurouting:_temp_route", transparent: true, format: 'image/png'},
            {singleTile: false, opacity: 0.7, isBaseLayer: false, visibility: true, noLegend: false, 
			featureInfoFormat: 'application/vnd.ogc.gml', transitionEffect: 'null', metadata: {
                wfs: {
                    protocol: 'fromWMSLayer',
                    downloadFormats: Heron.options.wfs.downloadFormats
                }
            }}
    ),
	Target: new OpenLayers.Layer.WMS(
            "Target",
            Heron.scratch.urls.OWS,
            {layers: "nurouting:_vill_selected", transparent: true, format: 'image/png'},
            {singleTile: false, opacity: 1, isBaseLayer: false, visibility: true, noLegend: false, 
			featureInfoFormat: 'application/vnd.ogc.gml', transitionEffect: 'null', metadata: {
                wfs: {
                    protocol: 'fromWMSLayer',
                    downloadFormats: Heron.options.wfs.downloadFormats
                }
            }}
    ),
	Source: new OpenLayers.Layer.WMS(
            "Source",
            Heron.scratch.urls.OWS,
            {layers: "nurouting:nu_poi", transparent: true, format: 'image/png'},
            {singleTile: false, opacity: 1, isBaseLayer: false, visibility: true, noLegend: false, 
			featureInfoFormat: 'application/vnd.ogc.gml', transitionEffect: 'null', metadata: {
                wfs: {
                    protocol: 'fromWMSLayer',
                    downloadFormats: Heron.options.wfs.downloadFormats
                }
            }}
    )
};

Heron.options.map.layers = [	
	//add Overlays 
	Heron.scratch.layermap.ServiceArea,
	Heron.scratch.layermap.Transportation,	
	Heron.scratch.layermap.Route,
	Heron.scratch.layermap.Target,
	Heron.scratch.layermap.Source,
	//Add BaseLayers   
	Heron.scratch.layermap.gstr,
	Heron.scratch.layermap.gter,
	Heron.scratch.layermap.gsat,
	Heron.scratch.layermap.ghyb
	
];


var treeTheme = [	
	{
		text:'OverlayMaps', 
		expanded: true,	
		children:
			[	
				{nodeType: "gx_layer", layer: "Source", legend: true},
				{nodeType: "gx_layer", layer: "Target", legend: true},
				{nodeType: "gx_layer", layer: "Route", legend: true},
				{nodeType: "gx_layer", layer: "Transportation", legend: true},	
				{nodeType: "gx_layer", layer: "ServiceArea", legend: true}				
			]
	/*
	},{
		text:'ชั้นข้อมูลการมีงานทำของบัณฑิตแยกรายคณะ', 
		expanded: true,
		children:
			[
				
			]
	*/
	},{
		text:'BaseMaps', expanded: true,	
		nodeType: "gx_baselayercontainer"
	}
];

