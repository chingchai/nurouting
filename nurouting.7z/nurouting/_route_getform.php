<?php
    include "../connect/connect_route.php";
    //conndb();

    $province_id = $_POST['province'];
    $amphur_id = $_POST['amphoe'];
    $district_id = $_POST['tambon'];
    $vill_id = $_POST['village'];
	$distance = $_POST['distance'];

    $sql_1 = "SELECT * FROM province WHERE prov_code = '$province_id' ";
    $result_1 = pg_query($sql_1);
    $row_1 = pg_fetch_array($result_1);
    $province_name = $row_1['prov_nam_t'];

    $sql_2 = "SELECT * FROM amphoe WHERE amp_code = '$amphur_id' ";
    $result_2 = pg_query($sql_2);
    $row_2 = pg_fetch_array($result_2);
    $amphur_name = $row_2['amp_nam_t'];

    $sql_3 = "SELECT * FROM tambon WHERE tam_code = '$district_id' ";
    $result_3 = pg_query($sql_3);
    $row_3 = pg_fetch_array($result_3);
    $district_name = $row_3['tam_nam_t'];
	
	$sql_4 = "SELECT * FROM village WHERE vill_code = '$vill_id' ";
    $result_4 = pg_query($sql_4);
    $row_4 = pg_fetch_array($result_4);
    $vill_name = $row_4['vill_nam_t'];
	$vill_x = $row_4['x'];
	$vill_y = $row_4['y'];
	
	
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <p>จังหวัด : <?php echo $province_name." (".$province_id.")"; ?>
        </br>อำเภอ : <?php echo $amphur_name." (".$amphur_id.")"; ?>
        </br>ตำบล : <?php echo $district_name." (".$district_id.")"; ?>		
        </br>หมู่บ้าน : <?php echo $vill_name." (".$vill_id.")"; ?>
		
		<br>-----------------------------------------------</br>	
		
		<?php	
		
		// vill 
		pg_query("DROP VIEW _vill_selected;");
		pg_query("CREATE VIEW _vill_selected AS SELECT * FROM village WHERE vill_code = '".$vill_id."' ;");
		
		// routing
		pg_query("DROP VIEW _temp_route;");
		pg_query("CREATE VIEW _temp_route AS SELECT * FROM pgr_fromAtoB('transportation',11153388.429,1890846.578,".$vill_x.",".$vill_y.");");
		
		// service area
		pg_query("DROP TABLE alpha_nodes; DROP TABLE alpha_polygon;");
		pg_query("SELECT id, id1 AS node, id2 AS edge, cost, the_geom
		INTO alpha_nodes
		  FROM pgr_drivingdistance(
			'SELECT gid as id, source, target, length as cost,rcost::double precision as reverse_cost FROM transportation',
			4214, ".$distance.", true, true
		  ) as di
		  JOIN transportation_vertices_pgr pt
		  ON di.id1 = pt.id;
		CREATE TABLE alpha_polygon AS
		SELECT ST_SetSRID(ST_MakePolygon(ST_AddPoint(foo.openline, ST_StartPoint(foo.openline)))::geometry,3857)as the_geom
		from (select st_makeline(points order by id)  as openline from
		(SELECT st_makepoint(x,y) as points ,row_number() over() AS id
		FROM pgr_alphAShape('SELECT id::integer, st_x(the_geom)::float as x, st_y(the_geom)::float as y  FROM alpha_nodes')
		) as a) as foo;");
		
		// check 
		$sql_5 = "SELECT ST_Within(a.geom, b.the_geom) as check from _vill_selected a, alpha_polygon b";
		$result_5 = pg_query($sql_5);
		$row_5 = pg_fetch_array($result_5);
		$check = $row_5['check'];
		
		//sum cost
		$sql_6 = "select ROUND(sum(cost)/1000) as sumcost from _temp_route"; 
		$result_6 = pg_query($sql_6);
		$row_6 = pg_fetch_array($result_6);
		$sumcost = $row_6['sumcost'];
		
		if((string)$check == "t"){
			
			echo "</br>จาก ".$vill_name." มายังมหาวิทยาลัยนเรศวร เป็นระยะทางทั้งหมด ".$sumcost." กิโลเมตร  <p>-----------------------------------------------</p>สถานะ: ไม่สามารถขอหอพักได้ ";
		}else{
			echo "</br>จาก ".$vill_name." มายังมหาวิทยาลัยนเรศวร เป็นระยะทางทั้งหมด ".$sumcost." กิโลเมตร  <p>-----------------------------------------------</p>สถานะ: สามารถขอหอพักได้";
		};
		?>
		<p>-----------------------------------------------</p>
		<p><a href="http://localhost/nurouting/_route.php">กลับไปเลือกเงื่อนไขใหม่อีกครั้ง</a></p>
		
    </body>
</html>
