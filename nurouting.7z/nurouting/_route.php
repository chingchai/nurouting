<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>NU Staff Dormitory Services(SDS)</title>
    </head>
    <script language=Javascript>
        function Inint_AJAX() {
           try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
           try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
           try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
           alert("XMLHttpRequest not supported");
           return null;
        };

        function dochange(src, val) {
             var req = Inint_AJAX();
             req.onreadystatechange = function () { 
                  if (req.readyState==4) {
                       if (req.status==200) {
                            document.getElementById(src).innerHTML=req.responseText; //รับค่ากลับมา
                       } 
                  }
             };
             req.open("GET", "_route_localtion.php?data="+src+"&val="+val); //สร้าง connection
             req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8"); // set Header
             req.send(null); //ส่งค่า
        }

        window.onLoad=dochange('province', -1);     
    </script>
    <body>
        <form name="form" method="post" action="_route_getform.php">
			
			<p>
			<p>โปรดเลือกระยะทางในการค้นหา </p>
			ระยะทาง : 
			<span id="distance">
			<select name="distance">
							<option >- เลือกระยะทาง -</option>
							<option value=5000>5km</option>
							<option value=10000>10km</option>
							<option value=15000>15km</option>						
							<option value=20000>20km</option>
							<option value=25000>25km</option>
							<option value=30000>30km</option>						
							<option value=40000>40km</option>
							<option value=50000>50km</option>
						</select>
					</span>
				</p>	
			<p>-----------------------------------------------</p>				
		<p>
		โปรดเลือกหมู่บ้านที่ต้องการค้นหา
		</p>
			<p>
			จังหวัด : 
                <span id="province" >
                    <select>
                        <option value="0">- เลือกจังหวัด -</option>
                    </select>
                </span>
            </p>
			
            <p>
			อำเภอ : 
                <span id="amphoe">
                    <select>
                        <option value='0'>- เลือกอำเภอ -</option>
                    </select>
                </span>
            </p>
			
            <p>
			ตำบล : 
                <span id="tambon">
                    <select>
                        <option value='0'>- เลือกตำบล -</option>
                    </select>
                </span>
            </p>
			
	       <p>
			หมู่บ้าน : 
                <span id="village">
                    <select>
                        <option value='0'>- เลือกหมู่บ้าน -</option>
                    </select>
                </span>
            </p>
			
			<p>-----------------------------------------------</p>	
			
            <input type="submit" name="Submit" value="ตกลง" style="width:60px"> <input type="reset" value="ยกเลิก" style="width:60px"> <input type="reset" value="zoom map" style="width:80px">
        </form>	
    </body>
</html>
